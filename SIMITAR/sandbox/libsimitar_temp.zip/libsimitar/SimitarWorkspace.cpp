/*
 * SimitarWorkspace.cpp
 *
 *  Created on: 27 de jul de 2017
 *      Author: anderson
 */

#include "SimitarWorkspace.h"

SimitarWorkspace::SimitarWorkspace()
{
	PLOG_INIT(debug);
	if (const char* env_p = std::getenv("SIMITAR_DATABASE"))
	{
		strcpy(m_database, env_p);
	}
	else
	{
		PLOG_ERROR << ERRORMSG_CANNOT_READ_ENVIMENMENT_VARIABLE
							<< "SIMITAR_DATABASE";
		exit(ERROR_CANNOT_READ_ENVIMENMENT_VARIABLE);
	}
	if (const char* env_p = std::getenv("SIMITAR_TEST_DATA_DIR"))
	{
		strcpy(m_dir_test, env_p);
	}
	else
	{
		PLOG_ERROR << ERRORMSG_CANNOT_READ_ENVIMENMENT_VARIABLE
							<< "SIMITAR_TEST_DATA_DIR";
		exit(ERROR_CANNOT_READ_ENVIMENMENT_VARIABLE);
	}
	if (const char* env_p = std::getenv("SIMITAR_CTD_XML_DIR"))
	{
		strcpy(m_dir_xml, env_p);
	}
	else
	{
		PLOG_ERROR << ERRORMSG_CANNOT_READ_ENVIMENMENT_VARIABLE
							<< "SIMITAR_CTD_XML_DIR";
		exit(ERROR_CANNOT_READ_ENVIMENMENT_VARIABLE);
	}

}

SimitarWorkspace::~SimitarWorkspace()
{
	// Nothing to do
}

string SimitarWorkspace::database()
{
	return string(m_database);
}

string SimitarWorkspace::testdir()
{
	return string(m_dir_test);
}

string SimitarWorkspace::xmldir()
{
	return string(m_dir_xml);
}
