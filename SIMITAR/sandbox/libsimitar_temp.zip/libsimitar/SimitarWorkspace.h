/*
 * SimitarWorkspace.h
 *
 *  Created on: 26 de jul de 2017
 *      Author: anderson
 */

#ifndef SIMITARWORKSPACE_H_
#define SIMITARWORKSPACE_H_

#include <iostream>
#include <cstdlib>
#include <stdlib.h>
#include <string.h>
#include <string>

#include "Defines.h"
#include "PlogMacros.h"

class SimitarWorkspace
{
public:
	/**
	 * Store environment variables of simitar framework.
	 * The env variables must be set before using this class
	 */
	SimitarWorkspace();

	/**
	 *
	 */
	virtual ~SimitarWorkspace();


	string database();

	string testdir();

	string xmldir();

private:
	char m_database[CHAR_BUFFER];
	char m_dir_test[CHAR_BUFFER];
	char m_dir_xml[CHAR_BUFFER];
};

#endif /* SIMITARWORKSPACE_H_ */
