int main(void)
{
	// must fail because there is no initializer
	auto i;

	return 0;
}
